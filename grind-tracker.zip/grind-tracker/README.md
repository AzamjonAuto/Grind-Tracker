# The Grind — Daily Tracker

A personal daily productivity tracker built as a single-page HTML app, hosted for free on GitHub Pages.

## Features
- 📅 Calendar view with daily tracking (P&L, cars sold, school, study, gym, spending)
- 📝 Flip any day card to add notes & daily goals
- 🎯 Monthly goals & plan section
- 📊 Quarterly summary reports
- 💡 Auto-rotating motivational quotes
- 🟢 Smart color-coding (green = productive, red = needs work)
- 💰 Friday paycheck tracking with retroactive week highlights
- 📤 Export / Import data to sync between devices

## Setup — GitHub Pages (Free Hosting)

1. **Create a GitHub repo**
   - Go to [github.com/new](https://github.com/new)
   - Name it something like `grind-tracker`
   - Set it to **Public** (required for free GitHub Pages)
   - Click **Create repository**

2. **Upload the files**
   - Click **"uploading an existing file"** on the repo page
   - Drag in `index.html` and `README.md`
   - Click **Commit changes**

3. **Enable GitHub Pages**
   - Go to **Settings** → **Pages**
   - Under "Source", select **Deploy from a branch**
   - Branch: **main**, folder: **/ (root)**
   - Click **Save**

4. **Access your tracker**
   - After a minute, your site will be live at:
   - `https://YOUR-USERNAME.github.io/grind-tracker/`

## Syncing Data Between Devices

Your data is saved in your browser's local storage. To move data between devices:

1. On **Device A**: Click **Export Data** → saves a `.json` file
2. Transfer the file (email it, AirDrop, Google Drive, etc.)
3. On **Device B**: Click **Import Data** → select the `.json` file

This merges all your tracking data, notes, and goals across devices.

## Customization

Everything is in a single `index.html` file — easy to tweak colors, scoring thresholds, or add new fields.
